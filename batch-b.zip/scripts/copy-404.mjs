import { copyFileSync } from 'node:fs'

// GitHub Pages не знає про маршрути SPA. Для невідомих адрес (наприклад, після F5 на /users)
// він віддає 404.html. Тому робимо його копією index.html: застосунок завантажиться,
// а vue-router сам покаже потрібну сторінку.
copyFileSync('dist/index.html', 'dist/404.html')
