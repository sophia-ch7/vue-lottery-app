export interface LoginCredentials {
  username: string
  password: string
}

export interface AuthUser {
  id: number
  username: string
  email: string
  firstName: string
  lastName: string
  gender: string
  image: string
}

export interface TokenPair {
  accessToken: string
  refreshToken: string
}

export type LoginResponse = AuthUser & TokenPair
